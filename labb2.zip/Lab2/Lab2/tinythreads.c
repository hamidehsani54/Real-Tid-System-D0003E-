#include <setjmp.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include "tinythreads.h"

#define NULL            0
#define DISABLE()       cli()     //DISABLE interrupts
#define ENABLE()        sei()	  //ENABLE interrupts
#define STACKSIZE       80
#define NTHREADS        4
#define SETSTACK(buf,a) *((unsigned int *)(buf)+8) = (unsigned int)(a) + STACKSIZE - 4; \
                        *((unsigned int *)(buf)+9) = (unsigned int)(a) + STACKSIZE - 4
						


struct thread_block {
    void (*function)(int);   // code to run
    int arg;                 // argument to the above
    thread next;             // for use in linked lists
    jmp_buf context;         // machine state
    char stack[STACKSIZE];   // execution stack space
};

struct thread_block threads[NTHREADS];  

struct thread_block initp;

thread freeQ   = threads;
thread readyQ  = NULL;
thread current = &initp;

int initialized = 0;

static void initialize(void) {
	PORTB |= (1<<PB7);									//activate pull-up registers for pin 7
	
	//timer interrupts
	CLKPR = 0x80;						//8Mhz 
	CLKPR = 0x00;						//CPU clock prescaler functionality disabled
	TCNT1 = 0;													//force the timer to start its first cycle from 0
	TCCR1A |= (1<<COM1A0) | (1<<COM1A1);						//set to high on compare match
	TCCR1B |= (1<<WGM12) | (1<<CS12) | (1<<CS10);				//sets the timer to Clear on Timer Compare mode
	OCR1A = 512;												//suitable value is the delay
	TIMSK1 = (1 << OCIE1A);										//timer output compare A interrupts enabled
	
/*
	//BUTTON INTERRUPTS
	DDRB = (1<<DDB3);			//configures port for input
	EIMSK |= (1<<PCIE1);		//pin change interrupt enable
	EICRA |= (1<<ISC01);		//enable interrupt detection on falling edge
	PCMSK1 |= (1<<PCINT15);		//PCINT15 corresponds to a change on pin 7 of PORTB.
*/
    int i;
    for (i=0; i<NTHREADS-1; i++)		
        threads[i].next = &threads[i+1];
    threads[NTHREADS-1].next = NULL;
	
    initialized = 1;
}

static void enqueue(thread p, thread *queue) {		
    p->next = NULL;
    if (*queue == NULL) {
        *queue = p;
    } else {
        thread q = *queue;
        while (q->next)
            q = q->next;
        q->next = p;
    }
}

static thread dequeue(thread *queue) {
    thread p = *queue;
    if (*queue) {
        *queue = (*queue)->next;
    } else {
        // Empty queue, kernel panic!!!
        while (1) ;  // not much else to do...
    }
    return p;
}

static void dispatch(thread next) {
    if (setjmp(current->context) == 0) {		//set state of thread, store context in current, check that dispatch only runs once.
        current = next;							//pause and resume at setjmp
        longjmp(next->context, 1);				//yield, jump back to previous setjmp to current process when child process is complete, returns 1 to setjmp
    }
}

void spawn(void (* function)(int), int arg) {
    thread newp;
	

    DISABLE();
    if (!initialized) initialize();


    newp = dequeue(&freeQ);	
    newp->function = function;		// " -> " gives newp value of function and then saves it in var function
    newp->arg = arg;
    newp->next = NULL;
	
	
    if (setjmp(newp->context) == 1) {
        ENABLE();
        current->function(current->arg);
        DISABLE();
		writeChar('4',4);
        enqueue(current, &freeQ);
        dispatch(dequeue(&readyQ));
    }
	
    SETSTACK(&newp->context, &newp->stack);

    enqueue(newp, &readyQ);
    ENABLE();
}

void yield(void) {
	DISABLE();							//disables interrupts
	enqueue(current, &readyQ);			//place a call to the queue
	dispatch(dequeue(&readyQ));			//dispatch the call at front of queue
	ENABLE();							//re-enables interrupts
}

void lock(mutex *m) {						//when the lock is active, no other process can access this thread
	DISABLE();								
	if(m->locked){					//if the mutex is locked:
		enqueue(current, &m->waitQ);		
		dispatch(dequeue(&readyQ));
	} else {
		m->locked = 1;						//if the mutex is unlocked: lock it
	}
	ENABLE();								//re-enable interrupts
}

void unlock(mutex *m) {				//unlocks the code so that other threads can access it
	DISABLE();							
	if(m->waitQ){					//if there is a process in the queue
		enqueue(current, &readyQ);				//add the next process to the queue
		dispatch(dequeue(&(m->waitQ)));			//dispatch the process at the front of the queue
	} else {
		m ->locked = 0;				//disable the lock in the mutex var
	}
	ENABLE();	
}

ISR(PCINT1_vect) {					//interrupt handler that causes involuntary yield	
	if((PINB & (1<<PB7)) == 0){			
		yield();						
	}
}

ISR(TIMER1_COMPA_vect) {			//generate a TIMER1_COMPA_vect interrupt (50ms with current initializations)
	yield();
}