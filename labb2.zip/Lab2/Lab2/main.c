/*
 * Lab2.c
 *
 * Created: 2021-02-03 11:44:43
 * Author : Dino
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

