/*
 * Joystick.c
 *
 * Created: 2021-02-25 14:10:48
 *  Author: dinolinoxd
 */ 

#include "GUI.h"
#include "Generator.h"
#include <avr/io.h>
#include "Joystick.h"
#include "writeToPortE.h"
int keyPress(){										//check which keyPress is active
	if((~PINB & ( 1 << 7 ))){						
		return 7;									//returns ints used in switch..case in updateGen function
	}
	if((~PINB & ( 1 << 6 ))){
		return 6;
	}
	if((~PINB & ( 1 << 4 ))){
		return 4;
	}
	if(( ~PINE & (1<<2))){
		return 2;
	}
	if(( ~PINE & (1<<3))){
		return 3;
	}
}


































/*
int keyPress(JOYSTICK *joystick){
	if(((PINB >> 6) & 1) == 0){
		writeChar('5',5);
		joystick->keyPressVar = 7;
		SYNC(joystick, &updateGenerator, 0);
		
	} else if (((PINB >> 7) & 1) == 0){
		writeChar('4',4);
		joystick->keyPressVar = 6;
		SYNC(joystick, &updateGenerator, 0);
		
	} 
	ASYNC(joystick->gui, &updateGUI, 0);
	ASYNC(joystick, &keyPress, 0);
}


int updateGenerator(JOYSTICK *joystick){
	if (((PINB >> 6) & 1) == 0){
		joystick->gui->currentGen->eh = 1;
		SYNC(joystick->gui->currentGen, &increaseFreq, 0);
		SYNC(joystick->gui, &updateGUI, 0);
		AFTER(MSEC(500), joystick, updateGenerator, 0);
	}
		
	if (((PINB >> 7) & 1) == 0){
		joystick->gui->currentGen->eh = 1;
		SYNC(joystick->gui->currentGen, &decreaseFreq, 0);
		SYNC(joystick->gui, &updateGUI, 0);
		AFTER(MSEC(500), joystick, updateGenerator, 0);
	}
		
	else {
		SYNC(joystick->gui, &updateGenerator, 0);
		//AFTER(MSEC(400), joystick, updateGenerator, 0);
	}
	return 0;
}


int update(JOYSTICK *joystick){
	if(((1 >> PB7) & 1 ) == 0){
		SYNC(joystick->gui->currentGen, &increaseFreq, 0);
		SYNC(joystick->gui, &updateGUI, 0);
	} else {
		SYNC(joystick->gui, &updateGUI, 0);
		AFTER(MSEC(400), joystick, update, 0);
	} 
	return 0;
}

*/