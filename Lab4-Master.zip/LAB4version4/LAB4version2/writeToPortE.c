/*
 * writeToPortE.c
 *
 * Created: 2021-02-28 12:43:50
 *  Author: dinolinoxd
 */ 
#include "GUI.h"
#include <avr/io.h>

//toggles the bit in portE between on/off, then repeats
void oscillate(PortEobj *self, int port){
	PORTE ^= (1<<port);
}

void resetOS(PortEobj *self, int port){
	writeChar('5',3);
	PORTE &= ~(1<<port);
}
