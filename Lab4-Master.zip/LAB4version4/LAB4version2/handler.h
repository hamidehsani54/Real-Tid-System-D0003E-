/*
 * handler.h
 *
 * Created: 2021-02-26 13:42:45
 *  Author: dinolinoxd
 */ 


#ifndef HANDLER_H_
#define HANDLER_H_

typedef struct{
	Object super;
	JOYSTICK *joystick;
} HANDLER;

#define initHANDLER(joystick){initObject(), joystick};



#endif /* HANDLER_H_ */