/*
 * writeToPortE.h
 *
 * Created: 2021-02-28 12:44:13
 *  Author: dinolinoxd
 */ 


#ifndef WRITETOPORTE_H_
#define WRITETOPORTE_H_
#include "TinyTimber.h"

typedef struct{
	Object super;
	int plswork;
	
} PortEobj;

void oscillate(PortEobj *self, int port);
void resetOS(PortEobj *self, int port);

#define initportE(plswork){initObject(), plswork}
#endif /* WRITETOPORTE_H_ */