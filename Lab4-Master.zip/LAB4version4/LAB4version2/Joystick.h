/*
 * Joystick.h
 *
 * Created: 2021-02-25 14:10:58
 *  Author: dinolinoxd
 */ 

#ifndef JOYSTICK_H_
#define JOYSTICK_H_

#include "GUI.h"
#include "TinyTimber.h"

typedef struct{
	Object super;
	GUI *gui;
	int singleEventCheck;
	int keyPressVar;
}JOYSTICK;

int keyPress();

#define initJoystick(gui, singleEventCheck, keyPressVar){initObject(), gui, singleEventCheck, keyPressVar} 


#endif /* JOYSTICK_H_ */