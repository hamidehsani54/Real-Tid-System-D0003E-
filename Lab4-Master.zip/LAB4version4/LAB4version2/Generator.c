/*
 * Generator.c
 *
 * Created: 2021-02-25 14:14:06
 *  Author: dinolinoxd
 */ 
#include "Generator.h"
#include "GUI.h"
#include "writeToPortE.h"

void increaseFreq(GENERATOR *self){
	if (self->active == 1){
		if(self->freq < 99){
			if(++self->freq == 1) sendtoWrite(self);
		}	
	}
}

void decreaseFreq(GENERATOR *self){
	if (self->active == 1){
		if(self->freq > 0){
			self->freq--;
		}
	}
}

//saves current freq to tempfreq, set tempfreq to 0, if freq=0 and click happens, restore the old freq
void tempFreq(GENERATOR *self){
	if (self->freq != 0){
		self->prevFreq = self->freq;
		self->freq = 0;
	}
	else if (self->freq == 0){
		self->freq = self->prevFreq;
	} 
	if(self->freq > 0) sendtoWrite(self);
}


void sendtoWrite(GENERATOR *self){
	if(self->freq > 0){
		ASYNC(self->portEobj, &oscillate, self->portE);
		AFTER(SEC(0.5/self->freq), self, &sendtoWrite,0);		//	1/freq = T, each period contains two states, oscillate twice per period
		}else{
		ASYNC(self->portEobj, &resetOS, self->portE);
	}
}
