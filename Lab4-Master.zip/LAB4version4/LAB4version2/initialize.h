/*
 * initialize.h
 *
 * Created: 2021-02-25 14:15:27
 *  Author: dinolinoxd
 */ 


#ifndef INITIALIZE_H_
#define INITIALIZE_H_

void INITIALIZE();



#endif /* INITIALIZE_H_ */