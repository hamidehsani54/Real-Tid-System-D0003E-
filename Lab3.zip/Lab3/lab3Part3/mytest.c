#include "tinythreads.h"
#include <stdbool.h>
#include <avr/io.h>
#include <stdint.h>
#include <stdio.h>
#include <avr/pgmspace.h>#include <string.h>
#include <setjmp.h>
#include <avr/interrupt.h>


int globalVar;
int buttonCount;


void joyStick_init(){		//initializes joyStick
	PORTB = (1<<PB7);		//activate pull-up registers
	DDRB = (1<<DDB3);		//configures port for input
}

void LCD_init(){
	LCDCRB = (1<<LCDCS) | (1<<LCDMUX1) | (1<<LCDMUX0) | (1<<LCDPM2) | (1<<LCDPM1) | (1<<LCDPM0) | 0<<LCD2B;		//BIAS/DUTY  MUX0/MUX1: 1, 1 = 1/4 Duty, LCDPMn 1,1,1 = 25 segments | TABLE 94
	LCDFRR = (0<<LCDPS0) | (0<<LCDPS1) | (0<<LCDPS2) | (1<<LCDCD2) | (1<<LCDCD1) | (1<<LCDCD0);					//LCDPSn 0,0,0 = prescaler N = 16 | LCDD 1,1,1 : prescaler divided by 8
	LCDCCR = (1<<LCDCC3) | (1<<LCDCC2) | (1<<LCDCC1) | (1<<LCDCC0) | (0<<LCDDC0)| (0<<LCDDC1) | (0<<LCDDC2);	//Contrast: 3.35V | Drive Time: 0 ,0 ,0 = 300microsec
	LCDCRA = (0<<LCDIE) | (1<<LCDEN) | (1<<LCDAB);																//no interrupt, LCD enabled, default waveform
}

void computePrimes(int pos) {
	long n;

	for(n = 1; ; n++) {
		if (isPrime(n) == 1)  {
			printAt(n, pos);
		}
	}
}

//help function to find out if given num is Prime or not
int isPrime(long num) {
	for (int j = 2; j < num; j++) {		
		if (!(num % j)) {
			return 0;
		}
	}
	return 1;
}

void printAt(int num, int pos) {
	int pp = pos;
	writeChar((num % 100) / 10 + '0', pp);
	pp++;
	writeChar(num % 10 + '0', pp);	
}

int joyStatePIN7(){			
	if (PINB & (1 << PB7)){
		return 1;
		} else {
		return 0;
	}
}

void button(int pos){		
	int singleEvent_check;
	DISABLE();		//disable interrupts when button is called so that the process is complete before next interrupt can occur
					//while loop is removed, instead the functions are event-driven
	if((joyStatePIN7() == 1) & (singleEvent_check == 1)){
		singleEvent_check = 0;				//when the joystick activation has been registered, the variable changes to 0 to enable the next joystick activation to register
	}
	if((joyStatePIN7() == 0) & (singleEvent_check == 0)){
		buttonCount += 1;
		printAt(buttonCount, pos);
		singleEvent_check = 1;				//when this is enabled, the continuing joystick inputs of "1" wont be registered until the joystick has been released.

	}
	ENABLE();	//reenable interrupts
}

void blink(int arg){			//removed the while-loop
	DISABLE();	
	if (LCDDR18 !=1){
		LCDDR18 |= 1 << 0;		//the function now works by turning off the segment if its on, or turning on if its off
	}
	else {
		LCDDR18 ^= 1 << 0;
	}
	ENABLE();
}


ISR(PCINT1_vect) {
	spawn(button,4);
	yield();
}

ISR(TIMER1_COMPA_vect) {			//generate a TIMER1_COMPA_vect interrupt
	spawn(blink, 2);
	yield();
}

void writeChar(char ch, int pos){
	//converts ASCII char to corresponding LCD display data
	int value = 0x0000;			//default int given to value
	if (ch == '0'){
		value = 0x1551;
	}
	
	else if (ch == '1'){
		value = 0x0110;
	}
	
	else if (ch == '2'){
		value = 0x1E11;
	}
	
	else if (ch == '3'){
		value = 0x1B11;
	}
	
	else if (ch == '4'){
		value = 0x0B50;
	}
	
	else if (ch == '5'){
		value = 0x1B41;
	}
	
	else if (ch == '6'){
		value = 0x1F41;
	}
	
	else if (ch == '7'){
		value = 0x0111;
	}
	
	else if (ch == '8'){
		value = 0x1F51;
	}
	
	else if (ch == '9'){
		value = 0x0B51;
	}
	
	if (pos == 1){
		//POS 0
		LCDDR0 = LCDDR0 | (value & 0xF)<< 4;		// | a | a | a | a | X | X | X | least significant number of value |
		LCDDR5 = LCDDR5 | (value>>4 & 0xF)<< 4;		// // | a | a | a | a | X | X | least significant number of value | X |
		LCDDR10 = LCDDR10 | (value>>8 & 0xF)<< 4;	// ...
		LCDDR15 = LCDDR15 | (value>>12 & 0xF) << 4;	// | a | a | a | a | X | X | X | X |					where X X X X = value
	}
	else if(pos == 0){
		//pos 1
		LCDDR0 = (value & 0xF);			 //| A | A | A | least significant number of value | x | x | x | x |
		LCDDR5 = (value>>4 & 0xF) ;			 //the 4 rightmost bits is for one of the two "display segments" in LCDDRx memory
		LCDDR10 = (value>>8 & 0xF) ;		 //the 4 leftmost bits are the second "display segment", where the other position should be written to
		LCDDR15 = (value>>12 & 0xF) ;	     //| 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |   (numbers = which display the bits correlate to)
	}
	
	else if(pos == 3){
		//POS 2
		LCDDR1 =  (value & 0xF)<< 4;
		LCDDR6 =  (value>>4 & 0xF)<< 4;
		LCDDR11 =  (value>>8 & 0xF)<< 4;
		LCDDR16 =  (value>>12 & 0xF)<< 4;
	}
	else if(pos == 2){
		//POS 3
		LCDDR1 = (value & 0xF);
		LCDDR6 = (value>>4 & 0xF);
		LCDDR11 = (value>>8 & 0xF);
		LCDDR16 = (value>>12 & 0xF);
	}
	else if(pos == 5){
		//POS 4
		LCDDR2 = LCDDR2 | (value & 0xF) << 4;
		LCDDR7 = LCDDR7 | (value>>4 & 0xF) << 4;
		LCDDR12 = LCDDR12 | (value>>8 & 0xF) << 4;
		LCDDR17 = LCDDR17 | (value>>12 & 0xF) << 4;
		
	}
	//POS 5
	else if(pos == 4){
		LCDDR2 = (value & 0xF);
		LCDDR7 = (value>>4 & 0xF);
		LCDDR12 = (value>>8 & 0xF);
		LCDDR17 = (value>>12 & 0xF);
	}
}

int main(void) {
	LCDDR18 |= 1 << 0;		//init display segment for blink to start from "on" state
	joyStick_init();
	LCD_init();
	spawn(button, 0);
	computePrimes(0);		//fix: if computePrimes is removed: place a call to computeprimes(0) at every event 
}

