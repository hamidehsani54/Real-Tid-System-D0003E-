/*
 * UsartInput.h
 *
 * Created: 2022-01-18 01:11:24
 *  Author: Ameer Alkadhimi
 *  Author: Pehr H�ggqvist
 *  Author: Hamid Qurban
 */ 
#include "TinyTimber.h"
#include "Controller.h"

#ifndef USARTINPUT_H_
#define USARTINPUT_H_


typedef struct {
	Object super;
	Controller *controller;
} UsartInput;

#define NorthBoundCarSensor (1 << 0)
#define NorthBoundBridgeSensor (1 << 1)
#define SouthBoundCarSensor (1 << 2)
#define SouthBoundBridgeSensor (1 << 3)

void reciveFromSimulator(UsartInput* reciveInput);


#define initUsartInput(controller) { initObject(), controller }


#endif 