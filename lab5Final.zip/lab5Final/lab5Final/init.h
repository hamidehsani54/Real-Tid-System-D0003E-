/*
 * GUI.h
 *
 * Created: 2022-01-17 15:56:58
 *  Author: Ameer Alkadhimi
 *  Author: Pehr H�ggqvist
 *  Author: Hamid Qurban
 */ 
#ifndef INIT_H_
#define INIT_H_
#define FOSC 8000000
#define BAUD 9600
#define MYUBRR (FOSC/16/BAUD-1)

void init();
void LCD_init();
void USART_init(unsigned int ubrr);


#endif 