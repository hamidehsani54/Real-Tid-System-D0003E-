/*
 * Controller.h
 *
 * Created: 2022-01-17 16:10:47
 *  Author: Ameer Alkadhimi
 *  Author: Pehr H�ggqvist
 *  Author: Hamid Qurban
 */ 
#include <avr/io.h>
#include <stdbool.h>
#include "TinyTimber.h"
#include "GUI.h"


#ifndef CONTROLLER_H_
#define CONTROLLER_H_
#define Red 0xA
#define SouthGreen 0x6
#define NorthGreen 0x9
#define CarTime 1
#define MAXCAR 5
#define TRAVELTIME 5
#define North 1
#define South 2

typedef struct {
	Object super;
	int southCarInBridge;
	int northCarInBridge;
	int northQueue;
	int southQueue;
	int currentSide;
	int carsPassed;
	GUI *gui;
} Controller;
void addCarToBridge(Controller *self, int side);
void removeCarFromBridge(Controller *self, int side);
void addCarToQueue(Controller *self, int side);
void removeCarFromQueue(Controller *self, int side);
void trafficLights(Controller *self, int arg);
void sendToSimulator(Controller *self, uint8_t sig);


#define initController(gui) { initObject(),0,0, 0, 0, 1, 0, gui }

#endif 