/*
 * GUI.c
 *
 * Created: 2022-01-17 15:56:58
 *  Author: Ameer Alkadhimi
 *  Author: Pehr H�ggqvist
 *  Author: Hamid Qurban
 */ 
#include <avr/io.h>
#include "GUI.h"
#include "Controller.h"

#define SOUTHPOS 0
#define BRIDGEPOS 2
#define NORTHPOS 4


void writeChar( char ch, int pos){
	unsigned char charNumber[4];
	if (pos >= 0 || pos <= 5){

		switch(ch){
			case '0':
			charNumber[0] = 0x1;
			charNumber[1] = 0x5;
			charNumber[2] = 0x5;
			charNumber[3] = 0x1;
			break;

			case '1':
			charNumber[0] = 0x0;
			charNumber[1] = 0x1;
			charNumber[2] = 0x1;
			charNumber[3] = 0x0;
			break;

			case '2':
			charNumber[0] = 0x1;
			charNumber[1] = 0xE;
			charNumber[2] = 0x1;
			charNumber[3] = 0x1;

			break;

			case '3':
			charNumber[0] = 0x1;
			charNumber[1] = 0xB;
			charNumber[2] = 0x1;
			charNumber[3] = 0x1;

			break;

			case '4':
			charNumber[0] = 0x0;
			charNumber[1] = 0xB;
			charNumber[2] = 0x5;
			charNumber[3] = 0x0;
			break;

			case '5':
			charNumber[0] = 0x1;
			charNumber[1] = 0xB;
			charNumber[2] = 0x4;
			charNumber[3] = 0x1;
			break;

			case '6':
			charNumber[0] = 0x1;
			charNumber[1] = 0xF;
			charNumber[2] = 0x4;
			charNumber[3] = 0x1;
			break;

			case '7':
			charNumber[0] = 0x0;
			charNumber[1] = 0x1;
			charNumber[2] = 0x1;
			charNumber[3] = 0x1;

			break;

			case '8':
			charNumber[0] = 0x1;
			charNumber[1] = 0xF;
			charNumber[2] = 0x5;
			charNumber[3] = 0x1;

			break;

			case '9':
			charNumber[0] = 0x1;
			charNumber[1] = 0xB;
			charNumber[2] = 0x5;
			charNumber[3] = 0x1;

			break;
		}
		if(pos == 0){
			LCDDR0 = (LCDDR0 & 0xF0) | charNumber[3] ;
			LCDDR5 = (LCDDR5 & 0xF0) | charNumber[2];
			LCDDR10 = (LCDDR10 & 0xF0) | charNumber[1];
			LCDDR15 = (LCDDR15 & 0xF0 ) | charNumber[0];

		}
		if (pos == 2){
			LCDDR1 = (LCDDR1 & 0xF0) | charNumber[3];
			LCDDR6 = (LCDDR6 & 0xF0) | charNumber[2];
			LCDDR11 = (LCDDR11 & 0xF0) | charNumber[1];
			LCDDR16 = (LCDDR16 & 0xF0) | charNumber[0];
		}
		if (pos == 4){
			LCDDR2 = (LCDDR2 & 0xF0) | charNumber[3];
			LCDDR7 = (LCDDR7 & 0xF0) | charNumber[2];
			LCDDR12 = (LCDDR12 & 0xF0) | charNumber[1];
			LCDDR17 = (LCDDR17 & 0xF0) | charNumber[0];
		}
	}
	if (pos == 1){
		LCDDR0 = (LCDDR0 & 0x0F) |(charNumber[3] << 4);
		LCDDR5 = (LCDDR5 & 0x0F) |(charNumber[2] << 4);
		LCDDR10 = (LCDDR10 & 0x0F) |(charNumber[1] << 4);
		LCDDR15 = (LCDDR15 & 0x0F) | (charNumber[0] << 4);
	}
	if (pos == 3){
		LCDDR1 = (LCDDR1 & 0x0F) | (charNumber[3] << 4);
		LCDDR6 = (LCDDR6 & 0x0F) | (charNumber[2] << 4);
		LCDDR11 = (LCDDR11 & 0x0F) | (charNumber[1] << 4);
		LCDDR16 = (LCDDR16 & 0x0F) | (charNumber[0] << 4);
	}
	if (pos == 5){
		LCDDR2 =  (LCDDR2 & 0x0F) |(charNumber[3] << 4);
		LCDDR7 = (LCDDR7 & 0x0F) |(charNumber[2] << 4);
		LCDDR12 =(LCDDR12 & 0x0F) | (charNumber[1] << 4);
		LCDDR17 = (LCDDR17 & 0x0F) |(charNumber[0] << 4);
	}

	
}



void printAt(int num, int pos) {
	writeChar( (num % 100) / 10 + '0', pos);
	pos++;
	writeChar( num % 10 + '0', pos);
}


void updateNorth(GUI *self, int arg) {
	printAt(arg, 4);
}


void updateSouth(GUI *self, int arg) {
	printAt(arg, 0);
}


void updateBridge(GUI *self, int arg) {
	printAt(arg, 2);
}