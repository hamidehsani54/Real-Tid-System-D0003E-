/*
 * UsartInput.c
 *
 * Created: 2022-01-18 01:10:17
 *  Author: Ameer Alkadhimi
 *  Author: Pehr H�ggqvist
 *  Author: Hamid Qurban
 */ 
#include <avr/io.h>
#include "UsartInput.h"
#define North 1
#define South 2

// retrieves data from simulator
void reciveFromSimulator(UsartInput *self) {

	while ( !(UCSR0A & (1 << RXC0)) );	
	
	uint8_t data = UDR0;		
	
	if (data & NorthBoundCarSensor) {
		ASYNC(self->controller, addCarToQueue, North );
	}
	else if (data & NorthBoundBridgeSensor) {
		ASYNC(self->controller, removeCarFromQueue, North);
	}
	else if (data & SouthBoundCarSensor) {
		ASYNC(self->controller, addCarToQueue, South);
	}
	else if (data & SouthBoundBridgeSensor) {
		ASYNC(self->controller, removeCarFromQueue, South);
	}
}

