/*
 * Controller.c
 *
 * Created: 2022-01-17 16:10:39
 *  Author: Ameer Alkadhimi
 *  Author: Pehr H�ggqvist
 *  Author: Hamid Qurban
 */ 

#include <avr/io.h>
#include "Controller.h"
#include "TinyTimber.h"
#include "GUI.h"
//The method processes the logic to determine the traffic light
//to be sent to sendToSimulator
void trafficLights(Controller *self, int arg) {
	if (self->northQueue == 0 && self->southQueue == 0) {
		ASYNC(self, sendToSimulator, Red);
		AFTER(SEC(TRAVELTIME), self,trafficLights, 0);
	}
	else if (self->northQueue > 0 && self->southQueue == 0) {
		if (self->southCarInBridge > 0 || self->northCarInBridge > 0) {
			AFTER(SEC(TRAVELTIME), self, trafficLights, 0);
		}
		else {
			ASYNC(self, sendToSimulator, NorthGreen);
			AFTER(SEC(CarTime), self, trafficLights, 0);
		}
	}
	else if (self->southQueue > 0 && self->northQueue == 0) {
		if (self->northCarInBridge > 0 || self->northCarInBridge > 0) {
			AFTER(SEC(TRAVELTIME), self, trafficLights, 0);
		}
		else {
			ASYNC(self, sendToSimulator, SouthGreen);
			AFTER(SEC(CarTime), self, trafficLights, 0);
		}
	}
	else {
		if (self->currentSide == North) {
			if (self->carsPassed < MAXCAR) {
				ASYNC(self, sendToSimulator, NorthGreen);
				self->carsPassed++;
				AFTER(SEC(CarTime), self, trafficLights, 0);
			}
			else {
				self->currentSide = South;
				self->carsPassed = 0;
				ASYNC(self, sendToSimulator, Red);
				AFTER(SEC(TRAVELTIME), self, trafficLights, 0);
			}
		}
		else if(self->currentSide == South)  {
			if (self->carsPassed < MAXCAR) {
				ASYNC(self, sendToSimulator, SouthGreen);
				self->carsPassed++;
				AFTER(SEC(CarTime), self, trafficLights, 0);
				} else {
				self->currentSide = North;
				self->carsPassed = 0;
				ASYNC(self, sendToSimulator, Red);
				AFTER(SEC(TRAVELTIME), self, trafficLights, 0);
			}
		}
	}
}


//method add cars to bridge and updates the LCD
void addCarToBridge(Controller *self, int side){
	if (side == North)
	{
		self->northCarInBridge++;
		ASYNC(self->gui, updateBridge, self->northCarInBridge);
		AFTER(SEC(TRAVELTIME), self, removeCarFromBridge, North);
	}
	else if (side == South)
	{
		self->southCarInBridge++;
		ASYNC(self->gui, updateBridge, self->southCarInBridge);
		AFTER(SEC(TRAVELTIME), self, removeCarFromBridge, South);
	}
}
//method empties the bridge and updates the LCD
void removeCarFromBridge(Controller *self, int side){
	if (side == North)
	{
		if (self->northCarInBridge > 0) {
			self->northCarInBridge--;
			ASYNC(self->gui, updateBridge, self->northCarInBridge);
		}
	}
	else if (side == South)
	{
		if (self->southCarInBridge > 0) {
			self->southCarInBridge--;
			ASYNC(self->gui, updateBridge, self->southCarInBridge);
		}
		
	}
}
//method increase the queue and updates the LCD
void addCarToQueue(Controller *self, int side){
	if (side == North)
	{
		self->northQueue++;
		ASYNC(self->gui, updateNorth, self->northQueue);
	}
	else if (side == South)
	{
		self->southQueue++;
		ASYNC(self->gui, updateSouth, self->southQueue);
		
	}
}
//method decrease the queue and updates the LCD
void removeCarFromQueue(Controller *self, int side){
	if (side == North)
	{
		self->northQueue--;
		ASYNC(self->gui, updateNorth, self->northQueue);
		ASYNC(self, addCarToBridge, North);
	}
	else if (side == South)
	{
		self->southQueue--;
		ASYNC(self->gui, updateSouth, self->southQueue);
		ASYNC(self, addCarToBridge, South);
		
	}
}

// Send data to simulator
void sendToSimulator(Controller *self, uint8_t data) {
	
	while ( !(UCSR0A & ( 1<< UDRE0)) );  
	UDR0 = data;
}