/*
 * GUI.h
 *
 * Created: 2022-01-17 15:56:58
 *  Author: Ameer Alkadhimi
 *  Author: Pehr H�ggqvist
 *  Author: Hamid Qurban
 */ 

#include <avr/io.h>
#include "init.h"
#include "GUI.h"


void init() {
	
	LCD_init();
	USART_init( MYUBRR );

}

void LCD_init() {
	
	//Clock prescaler
	CLKPR = 0x80;
	CLKPR = 0x00;
	//LCD
	LCDCRA = 0xC0;			//LCD ENABLE and LOW POWER WAVEFORM
	LCDCRB = 0xB7;			//AsyncClock, 1/3 Bias, 1/4 Duty, 25 Segments
	LCDFRR = 0x07;			//LCD Clock Divide 32 Hz
	LCDCCR = 0x0F;			//3.35 Volt
	TCCR1B = 0x0D;			//Clock prescaler set to 1024 and CFC.
	//LCDDR17 = 0x10;		//Initial d section lit.
	//Ports
	PORTB ^= 0xD0;			//PORTB = (1 << PORTB7)|(1 << PORTB6)|(1 << PORTB4);
	PORTE ^= 0x0c;			//PORTE = (1 << PORTE3)|(1 << PORTE2);

	
	//Pin Interrupt
	PCMSK0 = 0x0c;			//Pin change interrupt enabled on corresponding I/O pin.
	PCMSK1 = 0xd0;
	EIFR = 0xc0;			//Interrupt request
	EIMSK = 0xc0;			//Cause an interrupt
	
	/* Print initial traffic data */
	printAt(00, 0); printAt(00, 2); printAt(00, 4);
	
}

// Initialize USART drivers 
void USART_init( unsigned int ubrr ) {
	
	// Set baud rate 
	UBRR0H = (unsigned char)(ubrr>>8);
	UBRR0L = (unsigned char)ubrr;
	
	// Enable receive interrupts, enable receiver, enable transmitter 
	UCSR0B = (1 << RXCIE0) | (1 << RXEN0) | (1 << TXEN0);
	
	// Set transmitter and receiver data size to 8 bits 
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
	
}
