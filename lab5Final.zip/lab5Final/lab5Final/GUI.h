/*
 * GUI.h
 *
 * Created: 2022-01-17 15:56:58
 *  Author: Ameer Alkadhimi
 *  Author: Pehr H�ggqvist
 *  Author: Hamid Qurban
 */ 
#include "TinyTimber.h"

#ifndef GUI_H_
#define GUI_H_

typedef struct {
	Object super;
} GUI;

void writeChar(char ch, int pos);
void printAt(int num, int pos);
void updateNorth(GUI *self, int arg);
void updateSouth(GUI *self, int arg);
void updateBridge(GUI *self, int arg);

#define initGUI() { initObject() }

#endif