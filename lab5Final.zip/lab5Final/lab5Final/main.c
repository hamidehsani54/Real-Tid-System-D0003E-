/*
 * GUI.h
 *
 * Created: 2022-01-17 15:24:28
 *  Author: Ameer Alkadhimi
 *  Author: Pehr H�ggqvist
 *  Author: Hamid Qurban
 */ 
#include <avr/io.h>
#include "TinyTimber.h"
#include "init.h"
#include "UsartInput.h"
#include "Controller.h"
#include "GUI.h"


int main(void)
{
	init();
	GUI gui = initGUI();
	Controller controller = initController(&gui);
	UsartInput input = initUsartInput(&controller);
	INSTALL(&input, reciveFromSimulator, IRQ_USART0_RX);
	return TINYTIMBER(&controller, trafficLights, 0);
}

