  
#ifndef JOYSTICK_H_
#define JOYSTICK_H_

void initJoystick();
int readJoystick();

#endif /* JOYSTICK_H_ */