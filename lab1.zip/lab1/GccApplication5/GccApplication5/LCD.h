	void initLCD();
void LCDWritePackage();
void writeLong(long i);
void writeChar(char ch, int pos);
void clear();