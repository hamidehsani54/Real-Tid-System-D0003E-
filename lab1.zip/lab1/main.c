#include <avr/io.h>
#include <stdint.h>
#include "LCDDISPLAY.h"
#include <string.h>

/*
Finally, demonstrate your LCD driver by implementing a program that continuously computes increasing prime numbers and prints them on the display. 
The prime numbers shall be computed in the simplest possible way: a long variable is incremented for each turn in a loop, and a helper function is_prime(long i)
is called to determine whether the value is a prime number and thus to be printed. The initial value for this variable can be any value you find meaningful. 
Implementing is_prime(i) is tentatively done by computing i % n (i.e., the remainder from division i/n) for all 2 <= n < i, and returning false (0) if any such 
expression is 0, true (1) otherwise.

Wrap up you solution in a function primes() that is called directly from main() after device initialization.

Examination: we will ask you to run your program and check your code for correct CPU clock prescaler; LCD initialization; implementation of the functions.
*/
int main(void)
{

    CLKPR = 0x80;
    CLKPR = 0x00;
    LCD_init();

    //An octal integer literal begins with the digit 0 and contains any of the digits 0 through 7, dont start long with 0.
    //writeLong(0);
    //part 1
    //primes(1);

    //part 2
    
    while(1){
        //blink();
    

    //part 3
    //button();
	

    //part 4
    singleApplication();
}}