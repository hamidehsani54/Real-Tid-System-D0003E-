/*
 * LCDDISPLAY.h
 *
 * Created: 2021-01-23 14:44:37
 *  Author: olive
 */ 


#ifndef LCDDISPLAYH
#define LCDDISPLAYH

void writeChar(char ch, int pos);
void LCD_Init();
void writeLong(long i);
void LCDWritepackage();
void blink();
void joyStick_init();
void button();
void primes(long num);
int isPrime(long num);
int primesCopy(long num);
int isPrimeCopy(long num);
void singleApplication();
int blinkCopy();
void writeCharCopy(char ch, int pos);
void writeLongCopy(long i);


#endif / LCDDISPLAYH */