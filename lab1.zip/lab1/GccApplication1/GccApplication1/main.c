#include <avr/io.h>
#include <stdint.h>
#include "LCDDISPLAY.h"

long currentPrime;
int isPrime(long i);
int state;

int main(void)
{
	long num;


	while(1){
		primes(long num);
		
	}
}


