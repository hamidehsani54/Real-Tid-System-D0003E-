/*
 * GUI.c
 *
 * Created: 2021-02-25 14:11:12
 *  Author: dinolinoxd
 */ 

#include <avr/io.h>
#include "Generator.h"
#include "GUI.h"
#include "writeToPortE.h"

void updateGUI(GUI *gui){
	printAt(gui);
}

void printAt(GUI *gui) {
	int pp = gui->currentGen->pos;
	int num = gui->currentGen->freq;
	writeChar((num % 100) / 10 + '0', pp);
	pp++;
	writeChar(num % 10 + '0', pp);
}

void writeChar(char ch, int pos){
	//converts ASCII char to corresponding LCD display data
	int value = 0x0000;			//default int given to value
	if (ch == '0'){
		value = 0x1551;
	}
	
	else if (ch == '1'){
		value = 0x0110;
	}
	
	else if (ch == '2'){
		value = 0x1E11;
	}
	
	else if (ch == '3'){
		value = 0x1B11;
	}
	
	else if (ch == '4'){
		value = 0x0B50;
	}
	
	else if (ch == '5'){
		value = 0x1B41;
	}
	
	else if (ch == '6'){
		value = 0x1F41;
	}
	
	else if (ch == '7'){
		value = 0x0111;
	}
	
	else if (ch == '8'){
		value = 0x1F51;
	}
	
	else if (ch == '9'){
		value = 0x0B51;
	}
	if (pos == 0){
		//POS 0
		LCDDR0 = (value & 0xF);		// | a | a | a | a | X | X | X | least significant number of value |
		LCDDR5 = (value>>4 & 0xF);		// // | a | a | a | a | X | X | least significant number of value | X |
		LCDDR10 = (value>>8 & 0xF);	// ...
		LCDDR15 = (value>>12 & 0xF);	// | a | a | a | a | X | X | X | X |					where X X X X = value
	}
	else if(pos == 1){
		//pos 1
		LCDDR0 |= (value & 0xF) << 4;			 //| A | A | A | least significant number of value | x | x | x | x |
		LCDDR5 |= (value>>4 & 0xF) << 4;			 //the 4 rightmost bits is for one of the two "display segments" in LCDDRx memory
		LCDDR10 |= (value>>8 & 0xF) << 4;		 //the 4 leftmost bits are the second "display segment", where the other position should be written to
		LCDDR15 |= (value>>12 & 0xF) << 4;	     //| 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |   (numbers = which display the bits correlate to)
	}
	
	else if(pos == 2){
		//POS 2
		LCDDR1 = (value & 0xF);
		LCDDR6 = (value>>4 & 0xF);
		LCDDR11 = (value>>8 & 0xF);
		LCDDR16 = (value>>12 & 0xF);
	}
	else if(pos ==3){
		//POS 3
		LCDDR1 |= (value & 0xF)  <<4;
		LCDDR6 |= (value>>4 & 0xF)  << 4;
		LCDDR11 |= (value>>8 & 0xF) << 4;
		LCDDR16 |= (value>>12 & 0xF) << 4;
	}
	else if(pos == 4){
		//POS 4
		LCDDR2 = (value & 0xF);
		LCDDR7 = (value>>4 & 0xF);
		LCDDR12 = (value>>8 & 0xF);
		LCDDR17 = (value>>12 & 0xF);
		
	}
	//POS 5
	else if(pos == 5){
		LCDDR2 |= (value & 0xF)   << 4;
		LCDDR7 |= (value>>4 & 0xF)  << 4;
		LCDDR12 |= (value>>8 & 0xF) << 4;
		LCDDR17 |= (value>>12 & 0xF) << 4;
	}
}

void switchToGen1(GUI *gui){
	if (gui->currentGen == gui->Gen1){
		gui->Gen1->active = 0;
		gui->currentGen = gui->Gen2;
		gui->currentGen->active = 1;
		
		LCDDR2 = 0x0;
		LCDDR7 = 0x0;
		LCDDR12 = 0x0;
		LCDDR17	= 0x0;
	
	}
}

void switchToGen2(GUI *gui){
	if (gui->currentGen == gui->Gen2){
		gui->Gen2->active = 0;
		gui->currentGen = gui->Gen1;
		gui->currentGen->active = 1;
		
		LCDDR0 = 0x0;
		LCDDR5 = 0x0;
		LCDDR10 = 0x0;
		LCDDR15	= 0x0;
		
		
	}
}

void updateGen(GUI *gui){							//updates the frequency of the currentGen if the keyPress registered is pin 7 or pin 6
	switch(keyPress()){
		case 6:
		SYNC(gui->currentGen, &increaseFreq, 0);		//sync-call to increase the frequency of the current generator
		AFTER(MSEC (300), gui, &updateGen, 0);
		break;
		
		case 7:
		SYNC(gui->currentGen, &decreaseFreq, 0);		//sync-call to decrease the frequency of the current generator
		AFTER(MSEC (300), gui, &updateGen, 0);
		break;
		
		case 4:
		tempFreq(gui->currentGen);			//sync-call to save the value of current Freq, and if the "temp freq" is 0, restore the freq.
		break;
		
		case 3:
		switchToGen2(gui);
		break;
		
		case 2:
		switchToGen1(gui);
		break;
		
		default:
		SYNC(gui, &updateGUI, 0);
	}
	repeatWrite(gui);
	updateGUI(gui);
}