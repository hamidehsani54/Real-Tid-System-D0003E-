/*
 * LAB4version2.c
 *
 * Created: 2021-02-25 14:08:27
 * Author : dinolinoxd
 */ 

#include <avr/io.h>
#include "initialize.h"
#include "GUI.h"
#include "Joystick.h"
#include "Generator.h"
#include "handler.h"
#include "writeToPortE.h"

GENERATOR Gen1 = initGENERATOR(0, 0, 4, 0, 4);	//(... | ... | ... | ... | pinE)
GENERATOR Gen2 = initGENERATOR(0, 1, 0, 0, 6);
GUI gui = initGUI(&Gen2, &Gen1, &Gen2, 0);		//(current | gen1 | gen2)
JOYSTICK joystick = initJoystick(&gui, 1, 0);
HANDLER handler = initHANDLER(&joystick);
PortEobj portEobj = initWriteToPortE(&gui);

typedef struct{
	Object super;
	GUI *gui;
	GENERATOR* Gen1;
	GENERATOR* Gen2;
	HANDLER *handler;
	JOYSTICK *joystick;
	}MainObj;

void run(MainObj *self);

int main(void)
{
	CLKPR = 0x80;
	CLKPR = 0x00;
	INITIALIZE();

	MainObj mainObj = {initObject(), &gui, &Gen1, &Gen2, &handler, &joystick};
	return TINYTIMBER(&mainObj, &run, 0);
}

void checkState(MainObj *self){
	ASYNC(self->gui, &updateGen, 0);
}

void run(MainObj *self){
	INSTALL(self, &checkState, IRQ_PCINT0);
	INSTALL(self, &checkState, IRQ_PCINT1);
}

