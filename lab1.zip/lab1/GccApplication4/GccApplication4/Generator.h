/*
 * Generator.h
 *
 * Created: 2021-02-25 14:14:17
 *  Author: dinolinoxd
 */ 
#ifndef GENERATOR_H_
#define GENERATOR_H_
#include "TinyTimber.h"

typedef struct{
	Object super;
	int freq;
	int active;
	int pos;
	int prevFreq;
	int portE;			//which bit in portE to write to
}GENERATOR;

void increaseFreq(GENERATOR *self);
void decreaseFreq(GENERATOR *self);
void tempFreq(GENERATOR *self);

#define initGENERATOR(freq, active, pos, prevFreq, portE){initObject(), freq, active, pos, prevFreq, portE}
#endif /* GENERATOR_H_ */