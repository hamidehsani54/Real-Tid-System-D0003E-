/*
 * writeToPortE.h
 *
 * Created: 2021-02-28 12:44:13
 *  Author: dinolinoxd
 */ 


#ifndef WRITETOPORTE_H_
#define WRITETOPORTE_H_
#include "GUI.h"

typedef struct{
	Object super;
	GUI *gui;
} PortEobj;

void oscillate(GUI *gui);
void repeatWrite(GUI *gui);

#define initWriteToPortE(gui){initObject(), gui}
#endif /* WRITETOPORTE_H_ */