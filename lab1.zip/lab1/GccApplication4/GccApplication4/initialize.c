/*
 * initialize.c
 *
 * Created: 2021-02-25 14:15:17
 *  Author: Dino, Oliver, Hamid
 */ 

#include <avr/io.h>

void INITIALIZE(){
	LCDCRB = (1<<LCDCS) | (1<<LCDMUX1) | (1<<LCDMUX0) | (1<<LCDPM2) | (1<<LCDPM1) | (1<<LCDPM0) | 0<<LCD2B;		//BIAS/DUTY  MUX0/MUX1: 1, 1 = 1/4 Duty, LCDPMn 1,1,1 = 25 segments | TABLE 94
	LCDFRR = (0<<LCDPS0) | (0<<LCDPS1) | (0<<LCDPS2) | (1<<LCDCD2) | (1<<LCDCD1) | (1<<LCDCD0);					//LCDPSn 0,0,0 = prescaler N = 16 | LCDD 1,1,1 : prescaler divided by 8
	LCDCCR = (1<<LCDCC3) | (1<<LCDCC2) | (1<<LCDCC1) | (1<<LCDCC0) | (0<<LCDDC0)| (0<<LCDDC1) | (0<<LCDDC2);	//Contrast: 3.35V | Drive Time: 0 ,0 ,0 = 300microsec
	LCDCRA = (0<<LCDIE) | (1<<LCDEN) | (1<<LCDAB);			//no interrupt, LCD enabled, default waveform
	
	PORTB = (1<<PB7) | (1<<PB6) | (1<<PB4);      //activate pull-up registers
	PORTE = (1<<PE2) | (1<<PE3);
	DDRB = DDRB & ~((1 << 7) | (1 << 6) |(1 << 4));				//configures port for input
	DDRE = DDRE & ~((1<<2) | (1<<3));
	EIMSK |= (1<<PCIE1) | (1<<PCIE0);									//pin change interrupt enable
	EICRA |= (1<<ISC01);									//enable interrupt detection on falling edge
	PCMSK1 |= (1<<PCINT15)|(1<<PCINT14)|(1<<PCINT12);									//PCINT15 corresponds to a change on pin 7 of PORTB.	
	PCMSK0 |= (1<<PCINT3)|(1<<PCINT2);											
}