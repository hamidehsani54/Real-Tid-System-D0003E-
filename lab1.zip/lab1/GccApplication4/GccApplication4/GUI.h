/*
 * GUI.h
 *
 * Created: 2021-02-25 14:11:06
 *  Author: dinolinoxd
 */ 
#ifndef GUI_H_
#define GUI_H_

#include "TinyTimber.h"
#include "Generator.h"

typedef struct{
	Object super;
	GENERATOR *currentGen;
	GENERATOR *Gen1;
	GENERATOR *Gen2;
	int runOnce;
	
}GUI;

void writeChar(char ch, int pos);
void printAt(GUI *gui);
void updateGUI(GUI *gui);
void switchToGen1(GUI *gui);
void switchToGen2(GUI *gui);
void updateGen(GUI *gui);

#define initGUI(currentGen, initGENERATOR1, initGENERATOR2, runOnce) {initObject(), currentGen, initGENERATOR1, initGENERATOR2, runOnce}
	
#endif /* GUI_H_ */