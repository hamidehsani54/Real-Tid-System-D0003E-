/*
 * writeToPortE.c
 *
 * Created: 2021-02-28 12:43:50
 *  Author: dinolinoxd
 */ 
#include "GUI.h"
#include <avr/io.h>


//toggles the bit in portE between on/off, then repeats
void oscillate(GUI *gui){
	if(gui->currentGen->active == 1){
		PORTE ^= PORTE & (1<<gui->currentGen->portE);
		AFTER(SEC(0.5/gui->currentGen->freq), gui, &oscillate, 0);		
	}
}

//a function for activating the oscillate function but only have one instance of it running at all times
void repeatWrite(GUI *gui){
	if (gui->runOnce == 0){
		if(gui->currentGen->active == 1){
			SYNC(gui, &oscillate, 0);
			gui->runOnce++;
		}	
	}
}

