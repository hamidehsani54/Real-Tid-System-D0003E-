/*
 * Generator.c
 *
 * Created: 2021-02-25 14:14:06
 *  Author: dinolinoxd
 */ 
#include "Generator.h"
#include "GUI.h"

void increaseFreq(GENERATOR *self){
	if (self->active == 1){
		if(self->freq < 99){
			self->freq++;
		}	
	}
}

void decreaseFreq(GENERATOR *self){
	if (self->active == 1){
		if(self->freq > 0){
			self->freq--;
		}
	}
}

//saves current freq to tempfreq, set tempfreq to 0, if freq=0 and click happens, restore the old freq
void tempFreq(GENERATOR *self){
	if (self->freq != 0){
		self->prevFreq = self->freq;
		self->freq = 0;
	}
	else if (self->freq == 0){
		self->freq = self->prevFreq;
	} 
}
