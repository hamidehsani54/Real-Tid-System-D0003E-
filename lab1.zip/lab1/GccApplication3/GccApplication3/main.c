/*
 * GccApplication3.c
 *
 * Created: 2021-02-03 10:48:25
 * Author : Hamid Ehsani
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

