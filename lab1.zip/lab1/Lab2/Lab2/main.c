/*
 * Lab2.c
 *
 * Created: 2021-02-06 10:18:11
 * Author : Hamid Ehsani
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

