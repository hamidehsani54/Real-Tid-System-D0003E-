/*
 * LCDDISPLAY.c
 *
 * Created: 2021-01-23 14:44:17
 *  Author: Dino Lolic, Hamidullah Qurban, Oliver Johdet Piwek
 */ 

#include <avr/io.h>
#include "LCDDISPLAY.h"
#include <stdint.h>
#include <stdio.h>
#include <avr/pgmspace.h>#include <string.h>

//continously loops through integers and checks if they are prime, if they are prime: write the number on the LCD
void primes(long num){
	while (1) {
		if (isPrime(num)) {
			writeLong(num);
			num++;
		}
		num++;
	}
}

//help function to find out if given num is Prime or not
int isPrime(long num) {
	for (int j = 2; j < num; j++) {
		if (!(num % j)) {
			return 0;
		}
	}
	return 1;
}

void writeLong(long i){
	int pos = 5;			//write from right to left on the display
	
	if(i == 0){				//in the case of only one single 0 being translated to octal and not printing, bypass this with this if-statement.
		writeChar('0', pos);
	}
	else{										
		while((i >= 1) & (pos >= 0)){			//for each digit of the number
			writeChar((i%10) + '0', pos--);		//print least significant character on rightmost free pos  (default: 5)
			i = i/10;							//remove least significant char, pos-- for the next digit
		}	
	}
}
void LCD_init(){
	LCDCRB = (1<<LCDCS) | (1<<LCDMUX1) | (1<<LCDMUX0) | (1<<LCDPM2) | (1<<LCDPM1) | (1<<LCDPM0) | 0<<LCD2B;		//BIAS/DUTY  MUX0/MUX1: 1, 1 = 1/4 Duty, LCDPMn 1,1,1 = 25 segments | TABLE 94
	LCDFRR = (0<<LCDPS0) | (0<<LCDPS1) | (0<<LCDPS2) | (1<<LCDCD2) | (1<<LCDCD1) | (1<<LCDCD0);					//LCDPSn 0,0,0 = prescaler N = 16 | LCDD 1,1,1 : prescaler divided by 8										
	LCDCCR = (1<<LCDCC3) | (1<<LCDCC2) | (1<<LCDCC1) | (1<<LCDCC0) | (0<<LCDDC0)| (0<<LCDDC1) | (0<<LCDDC2);	//Contrast: 3.35V | Drive Time: 0 ,0 ,0 = 300microsec
	LCDCRA = (0<<LCDIE) | (1<<LCDEN) | (1<<LCDAB);																//no interrupt, LCD enabled, default waveform 
}

void writeChar(char ch, int pos){
	//converts ASCII char to corresponding LCD display data
	int value = 0x0000;			//default int given to value
	if (ch == '0'){
		value = 0x1551;	
	}
		
	else if (ch == '1'){
		value = 0x0110;
	}
		
	else if (ch == '2'){
		value = 0x1E11;
	}
		
	else if (ch == '3'){
		value = 0x1B11;
	}
		
	else if (ch == '4'){
		value = 0x0B50;
	}
		
	else if (ch == '5'){
		value = 0x1B41;
	}
		
	else if (ch == '6'){
		value = 0x1F41;
	}
		
	else if (ch == '7'){
		value = 0x0111;
	}
			
	else if (ch == '8'){
		value = 0x1F51;
	}
			
	else if (ch == '9'){
		value = 0x0B51;
	}
		if (pos == 0){
		//POS 0
			LCDDR0 = LCDDR0 | (value & 0xF);		// | a | a | a | a | X | X | X | least significant number of value |
			LCDDR5 = LCDDR5 | (value>>4 & 0xF);		// // | a | a | a | a | X | X | least significant number of value | X |
			LCDDR10 = LCDDR10 | (value>>8 & 0xF);	// ...
			LCDDR15 = LCDDR15 | (value>>12 & 0xF);	// | a | a | a | a | X | X | X | X |					where X X X X = value
		} 
		else if(pos == 1){
		//pos 1
			LCDDR0 = (value & 0xF) << 4;			 //| A | A | A | least significant number of value | x | x | x | x |
			LCDDR5 = (value>>4 & 0xF) << 4;			 //the 4 rightmost bits is for one of the two "display segments" in LCDDRx memory
			LCDDR10 = (value>>8 & 0xF) << 4;		 //the 4 leftmost bits are the second "display segment", where the other position should be written to
			LCDDR15 = (value>>12 & 0xF) << 4;	     //| 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |   (numbers = which display the bits correlate to)
		}
		
		else if(pos == 2){
		//POS 2
			LCDDR1 = LCDDR1 | (value & 0xF);
			LCDDR6 = LCDDR6 | (value>>4 & 0xF);
			LCDDR11 = LCDDR11 | (value>>8 & 0xF);
			LCDDR16 = LCDDR16 | (value>>12 & 0xF);
		}
		else if(pos ==3){
		//POS 3
			LCDDR1 = (value & 0xF)  <<4;
			LCDDR6 = (value>>4 & 0xF)  << 4;
			LCDDR11 = (value>>8 & 0xF) << 4;
			LCDDR16 = (value>>12 & 0xF) << 4;
		}
		else if(pos == 4){
		//POS 4
			LCDDR2 = LCDDR2 | (value & 0xF);
			LCDDR7 = LCDDR7 | (value>>4 & 0xF);
			LCDDR12 = LCDDR12 | (value>>8 & 0xF);
			LCDDR17 = LCDDR17 | (value>>12 & 0xF);
		
		}
		//POS 5
		else if(pos == 5){
			LCDDR2 = (value & 0xF)   << 4;
			LCDDR7 = (value>>4 & 0xF)  << 4;
			LCDDR12 = (value>>8 & 0xF) << 4;
			LCDDR17 = (value>>12 & 0xF) << 4;
		}
}



/*
PART 2:
Concretely, this program should maintain an unsigned integer variable representing the next timer value to wait for, 
and use busy-waiting to stop execution until register TCNT1 has reached that value. 
Note that blinking the display requires updating in two phases, that preferably last half the desired period.
*/

void blink(){
	LCDDR2 |= 1 << 6;									//display segment to be activated on display
	TCCR1B = (1<<CS12) | (0<<CS11) | (0<<CS10);			//sets the correct prescaler settings for the desired timer frequency tabel 59
	unsigned int timerValue = TCNT1 / 2.09712;			//8MHZ / 256(prescaler) -> 31.25 kilohertz, wraparound after 65535 (16 bits), 65535/2.09712 = 31.25 KHz
													//this gives us a blink that is just slightly over 1hz (true 1hz not possible on prescaler 256, 256 cannot be divided to 1hz)
	if((timerValue == 1) | (timerValue == 15625)){		//timer value to wait for when wraparound or timer hits half of TCNT1 occurs: turn LCD on/off
		LCDCRA ^= (1<<LCDEN);							//toggle the entire LCD display, worked for this part altough we modified it in the later part of the assignment
	}
}

void joyStick_init(){		//initializes joyStick
	PORTB = (1<<PB7);		//activate pull-up registers
	DDRB = (1<<DDB3);		//configures port for input
}

int joyStatePIN7(){			//help function to check if the bit 7 that is used for joystick control is activated or not.
	if (PINB & (1 << PB7)){
		return 1;
	} else {
		return 0;
	}
}

void button(){				
	joyStick_init();		//init the joystick when function is called,
	int singleEvent_check;	
	LCDDR0 = 1 << 6;		//one display segment is default turned on for them to run in seperate "toggles"
	
	while(1){
		if((joyStatePIN7() == 1) & (singleEvent_check == 1)){
			singleEvent_check = 0;				//when the joystick activation has been registered, the variable changes to 0 to enable the next joystick activation to register
		}
		if((joyStatePIN7() == 0) & (singleEvent_check == 0)){
			LCDDR1 ^= 1 << 6;	//toggle display segments on/off
			LCDDR0 ^= 1 << 6;
			singleEvent_check = 1;				//when this is enabled, the continuing joystick inputs of "1" wont be registered until the joystick has been released.
		}		
	}
}
	
//part 4	
void singleApplication(){
	TCCR1B = (1<<CS12) | (0<<CS11) | (0<<CS10);			//the blink() function has been included into this single application, so the other functions revolve around the timer in blink
	LCDDR18 = 1 << 0;									//enables display segment for button for it to toggle between two seperate segments
	joyStick_initCopy();	
	long savedPrime = 2;							//init the prime function with start value
	int singleEventCheck;								//variable used to save the value of the check, it is in place for the joystick to do something for single presses.
	
	while(1){			
		unsigned int timerValue = TCNT1 / 2.09712;				
		
		if(timerValue < 15625){									//if timer is in the first half of the 65535 bits of the timer, the display segment is turned on
			singleEventCheck = buttonCopy(singleEventCheck);	//perform part 1 and part 2 of the assignment while waiting for the next time the "timer state" changes
			savedPrime = primesCopy(savedPrime);				//calculate the current prime and the next one returned by savedPrime. 
			LCDDR2 |= 1 << 6;
							    
		} if (timerValue > 15625) {								//if timer is in the second half of the 65535 bits of the timer, the display segment is turned off
			singleEventCheck = buttonCopy(singleEventCheck);		
			savedPrime = primesCopy(savedPrime);
			LCDDR2 |= 0 << 6;
		}
	}
}
	

int primesCopy(long savedPrime){               //modifications: removed while loop, return the savedprime++(next value) to be called in next iteration           
		if (isPrimeCopy(savedPrime)) {         
			writeLongCopy(savedPrime);         
			savedPrime++;                      
			return savedPrime;                 
		}
		savedPrime++;
		return savedPrime;
}

//help function to find out if given num is Prime or not
int isPrimeCopy(long savedPrime) {						//modified the function by removing the while loop, the while part is instead performed in the singleApplication() function
	for (int j = 2; j < savedPrime; j++) {				
		if (!(savedPrime % j)) {
			return 0;
		}
	}
	return 1;
}

void joyStick_initCopy(){								//no modifications
	PORTB = (1<<PB7) | (1<<PB4);
	DDRB = (1<<DDB3) | (1<<DDB2);
}

int joyStatePIN7Copy(){									//no modifications
	if (PINB & (1 << PB7)){
		return 1;
		} else {
		return 0;
	}
}

int buttonCopy(int singleEvent_check){										//while loop has been stripped from the function, it is now performed in singleApplication()
	if((joyStatePIN7Copy() == 1) & (singleEvent_check == 1)){				
		singleEvent_check = 0;				
	}
	if((joyStatePIN7Copy() == 0) & (singleEvent_check == 0)){		
		LCDDR18 ^= 1 << 0;	//toggle display segment
		LCDDR8 ^= 1 << 0;	//toggle display segment
		return singleEvent_check;				
	}
}

void writeCharCopy(char ch, int pos){			//no modifications
	int value = 0x0000;
	//converts ASCII char to corresponding LCD display data
	if (ch == '0'){
		value = 0x1551;
	}
	
	else if (ch == '1'){
		value = 0x0110;
	}
	
	else if (ch == '2'){
		value = 0x1E11;
	}
	
	else if (ch == '3'){
		value = 0x1B11;
	}
	
	else if (ch == '4'){
		value = 0x0B50;
	}
	
	else if (ch == '5'){
		value = 0x1B41;
	}
	
	else if (ch == '6'){
		value = 0x1F41;
	}
	
	else if (ch == '7'){
		value = 0x0111;
	}
	
	else if (ch == '8'){
		value = 0x1F51;
	}
	
	else if (ch == '9'){
		value = 0x0B51;
	}
	if (pos == 0){
		//POS 0
		LCDDR0 = LCDDR0 | (value & 0xF);
		LCDDR5 = LCDDR5 | (value>>4 & 0xF);
		LCDDR10 = LCDDR10 | (value>>8 & 0xF);
		LCDDR15 = LCDDR15 | (value>>12 & 0xF);
	}
	else if(pos == 1){
		//pos 1
		LCDDR0 = (value & 0xF) << 4;
		LCDDR5 = (value>>4 & 0xF) << 4;
		LCDDR10 = (value>>8 & 0xF) << 4;
		LCDDR15 = (value>>12 & 0xF) << 4;
	}
	
	else if(pos == 2){
		//POS 2
		LCDDR1 = LCDDR1 | (value & 0xF);
		LCDDR6 = LCDDR6 | (value>>4 & 0xF);
		LCDDR11 = LCDDR11 | (value>>8 & 0xF);
		LCDDR16 = LCDDR16 | (value>>12 & 0xF);
	}
	else if(pos ==3){
		//POS 3
		LCDDR1 = (value & 0xF)  <<4;
		LCDDR6 = (value>>4 & 0xF)  << 4;
		LCDDR11 = (value>>8 & 0xF) << 4;
		LCDDR16 = (value>>12 & 0xF) << 4;
	}
	else if(pos == 4){
		//POS 4
		LCDDR2 = LCDDR2 | (value & 0xF);
		LCDDR7 = LCDDR7 | (value>>4 & 0xF);
		LCDDR12 = LCDDR12 | (value>>8 & 0xF);
		LCDDR17 = LCDDR17 | (value>>12 & 0xF);
	}
	
	//POS 5
	else if(pos == 5){
		LCDDR2 = (value & 0xF)   << 4;
		LCDDR7 = (value>>4 & 0xF)  << 4;
		LCDDR12 = (value>>8 & 0xF) << 4;
		LCDDR17 = (value>>12 & 0xF) << 4;
	}
}

void writeLongCopy(long i){
	int pos = 5;			//write from right to left on the display
	
	if(i == 0){				//in the case of only one single 0 being translated to octal and not printing, bypass this with this if-statement.
		writeChar('0', pos);
	}
	else{
		while((i >= 1) & (pos >= 0)){			//for each digit of the number
			writeChar((i%10) + '0', pos--);		//print least significant character on rightmost free pos  (default: 5)
			i = i/10;							//remove least significant char, pos-- for the next digit
		}
	}
}